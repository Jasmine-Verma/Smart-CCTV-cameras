# smart-cctv-tkinter
This is a tkinter gui app for converting your normal laptop camera to smart camera.


you just need to run main.py file inorder to run full app 

you would need :
opencv
tkinter

installed to run these scripts properly

video : https://youtu.be/L1ZQzdT4mEA

thanks ;) 

